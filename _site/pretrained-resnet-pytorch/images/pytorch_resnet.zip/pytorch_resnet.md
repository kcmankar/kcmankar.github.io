Importing all the necessary libraries.
Our Resnet is sotred in torchvision.model


```python
import torch
import matplotlib.pyplot as plt
import torch.nn as nn
import torch.optim as optim
import numpy as np
import torchvision
from torchvision import datasets, models, transforms
import torch.utils.data as data
```

If you are using colab then upload the zip file then unzip it.
In colab if you have to run a command use "!" in front of it


```python
!unzip /content/walk_or_run.zip
```

    Archive:  /content/walk_or_run.zip
      inflating: walk_or_run_test/test/run/run_0794de59.png  
      inflating: walk_or_run_test/test/run/run_0987572f.png  
      inflating: walk_or_run_test/test/run/run_0b30ced7.png  
      inflating: walk_or_run_test/test/run/run_0c98676d.png  
      inflating: walk_or_run_test/test/run/run_1073489f.png  
      inflating: walk_or_run_test/test/run/run_13662896.png  
      inflating: walk_or_run_test/test/run/run_1bb05084.png  
      inflating: walk_or_run_test/test/run/run_1ff02911.png  
      inflating: walk_or_run_test/test/run/run_20dcdbec.png  
      inflating: walk_or_run_test/test/run/run_26e292d1.png  
      inflating: walk_or_run_test/test/run/run_274eaee3.png  
      inflating: walk_or_run_test/test/run/run_2aab0e1b.png  
      inflating: walk_or_run_test/test/run/run_2b758aeb.png  
      inflating: walk_or_run_test/test/run/run_2bae0a9d.png  
      inflating: walk_or_run_test/test/run/run_2fe546c8.png  
      inflating: walk_or_run_test/test/run/run_3252a749.png  
      inflating: walk_or_run_test/test/run/run_34713f03.png  
      inflating: walk_or_run_test/test/run/run_365fa2e5.png  
      inflating: walk_or_run_test/test/run/run_3aa2c4e5.png  
      inflating: walk_or_run_test/test/run/run_3b89e223.png  
      inflating: walk_or_run_test/test/run/run_3d46b336.png  
      inflating: walk_or_run_test/test/run/run_3d560204.png  
      inflating: walk_or_run_test/test/run/run_3ea8d56c.png  
      inflating: walk_or_run_test/test/run/run_412b17b7.png  
      inflating: walk_or_run_test/test/run/run_41b7236f.png  
      inflating: walk_or_run_test/test/run/run_434d009d.png  
      inflating: walk_or_run_test/test/run/run_47e8074d.png  
      inflating: walk_or_run_test/test/run/run_603ac08a.png  
      inflating: walk_or_run_test/test/run/run_639a2946.png  
      inflating: walk_or_run_test/test/run/run_6b986002.png  
      inflating: walk_or_run_test/test/run/run_6c717b45.png  
      inflating: walk_or_run_test/test/run/run_6dd1dbbd.png  
      inflating: walk_or_run_test/test/run/run_7148ac65.png  
      inflating: walk_or_run_test/test/run/run_7244bb3e.png  
      inflating: walk_or_run_test/test/run/run_7666656e.png  
      inflating: walk_or_run_test/test/run/run_78b39d88.png  
      inflating: walk_or_run_test/test/run/run_7b173abd.png  
      inflating: walk_or_run_test/test/run/run_7cd0ad06.png  
      inflating: walk_or_run_test/test/run/run_7d5af605.png  
      inflating: walk_or_run_test/test/run/run_8064cca3.png  
      inflating: walk_or_run_test/test/run/run_82ee1773.png  
      inflating: walk_or_run_test/test/run/run_838fadaa.png  
      inflating: walk_or_run_test/test/run/run_849d4f97.png  
      inflating: walk_or_run_test/test/run/run_8713cf1c.png  
      inflating: walk_or_run_test/test/run/run_8ceeeca7.png  
      inflating: walk_or_run_test/test/run/run_90d5412b.png  
      inflating: walk_or_run_test/test/run/run_9417fa3e.png  
      inflating: walk_or_run_test/test/run/run_94545263.png  
      inflating: walk_or_run_test/test/run/run_94f53a29.png  
      inflating: walk_or_run_test/test/run/run_9ac4b498.png  
      inflating: walk_or_run_test/test/run/run_9b0e163e.png  
      inflating: walk_or_run_test/test/run/run_9baf8e76.png  
      inflating: walk_or_run_test/test/run/run_9d419641.png  
      inflating: walk_or_run_test/test/run/run_a0564e69.png  
      inflating: walk_or_run_test/test/run/run_acc06cbc.png  
      inflating: walk_or_run_test/test/run/run_b0f5ef5d.png  
      inflating: walk_or_run_test/test/run/run_b16636b7.png  
      inflating: walk_or_run_test/test/run/run_b56d5e91.png  
      inflating: walk_or_run_test/test/run/run_b5ff0667.png  
      inflating: walk_or_run_test/test/run/run_bbbc236a.png  
      inflating: walk_or_run_test/test/run/run_bde9d918.png  
      inflating: walk_or_run_test/test/run/run_be2d5f70.png  
      inflating: walk_or_run_test/test/run/run_c4e7d0ef.png  
      inflating: walk_or_run_test/test/run/run_c9f91d3a.png  
      inflating: walk_or_run_test/test/run/run_d7979a13.png  
      inflating: walk_or_run_test/test/run/run_dc393379.png  
      inflating: walk_or_run_test/test/run/run_dc953638.png  
      inflating: walk_or_run_test/test/run/run_dcd4f931.png  
      inflating: walk_or_run_test/test/run/run_df48f40f.png  
      inflating: walk_or_run_test/test/run/run_df6c7bfc.png  
      inflating: walk_or_run_test/test/run/run_e03c8978.png  
      inflating: walk_or_run_test/test/run/run_e15921b4.png  
      inflating: walk_or_run_test/test/run/run_ef7f2500.png  
      inflating: walk_or_run_test/test/run/run_f02b25c8.png  
      inflating: walk_or_run_test/test/run/run_f2e85951.png  
      inflating: walk_or_run_test/test/run/run_f3750b68.png  
      inflating: walk_or_run_test/test/run/run_f4bc7985.png  
      inflating: walk_or_run_test/test/run/run_f54c4d53.png  
      inflating: walk_or_run_test/test/run/run_f84978c2.png  
      inflating: walk_or_run_test/test/run/run_fd35e643.png  
      inflating: walk_or_run_test/test/run/run_fe77938f.png  
      inflating: walk_or_run_test/test/run/run_fee36129.png  
      inflating: walk_or_run_test/test/walk/walk_035124b5.png  
      inflating: walk_or_run_test/test/walk/walk_0c96b662.png  
      inflating: walk_or_run_test/test/walk/walk_1078e68d.png  
      inflating: walk_or_run_test/test/walk/walk_125cac5b.png  
      inflating: walk_or_run_test/test/walk/walk_158c0f76.png  
      inflating: walk_or_run_test/test/walk/walk_1aa6836f.png  
      inflating: walk_or_run_test/test/walk/walk_1eb5234a.png  
      inflating: walk_or_run_test/test/walk/walk_20564b8d.png  
      inflating: walk_or_run_test/test/walk/walk_21c38b60.png  
      inflating: walk_or_run_test/test/walk/walk_2d18506d.png  
      inflating: walk_or_run_test/test/walk/walk_3af52937.png  
      inflating: walk_or_run_test/test/walk/walk_3ba0de08.png  
      inflating: walk_or_run_test/test/walk/walk_3f87901d.png  
      inflating: walk_or_run_test/test/walk/walk_3fb09ff7.png  
      inflating: walk_or_run_test/test/walk/walk_4312afdd.png  
      inflating: walk_or_run_test/test/walk/walk_4416ab19.png  
      inflating: walk_or_run_test/test/walk/walk_443d602c.png  
      inflating: walk_or_run_test/test/walk/walk_46844120.png  
      inflating: walk_or_run_test/test/walk/walk_4d412d2a.png  
      inflating: walk_or_run_test/test/walk/walk_54e056b6.png  
      inflating: walk_or_run_test/test/walk/walk_55fc48a4.png  
      inflating: walk_or_run_test/test/walk/walk_5924fa61.png  
      inflating: walk_or_run_test/test/walk/walk_5bd87f4e.png  
      inflating: walk_or_run_test/test/walk/walk_5cb390fe.png  
      inflating: walk_or_run_test/test/walk/walk_5f25a007.png  
      inflating: walk_or_run_test/test/walk/walk_5ff2a9a1.png  
      inflating: walk_or_run_test/test/walk/walk_6c57b9b3.png  
      inflating: walk_or_run_test/test/walk/walk_73df008e.png  
      inflating: walk_or_run_test/test/walk/walk_79cb786b.png  
      inflating: walk_or_run_test/test/walk/walk_801f1410.png  
      inflating: walk_or_run_test/test/walk/walk_8304a88c.png  
      inflating: walk_or_run_test/test/walk/walk_96584b43.png  
      inflating: walk_or_run_test/test/walk/walk_98cfe2a0.png  
      inflating: walk_or_run_test/test/walk/walk_99774583.png  
      inflating: walk_or_run_test/test/walk/walk_9b6b8438.png  
      inflating: walk_or_run_test/test/walk/walk_9c35d4b1.png  
      inflating: walk_or_run_test/test/walk/walk_9d193f21.png  
      inflating: walk_or_run_test/test/walk/walk_9e646bbc.png  
      inflating: walk_or_run_test/test/walk/walk_ac2e711d.png  
      inflating: walk_or_run_test/test/walk/walk_b37fa854.png  
      inflating: walk_or_run_test/test/walk/walk_b7ae679c.png  
      inflating: walk_or_run_test/test/walk/walk_b9db848a.png  
      inflating: walk_or_run_test/test/walk/walk_c95d8645.png  
      inflating: walk_or_run_test/test/walk/walk_cdd1ca66.png  
      inflating: walk_or_run_test/test/walk/walk_d06fab89.png  
      inflating: walk_or_run_test/test/walk/walk_d20904e9.png  
      inflating: walk_or_run_test/test/walk/walk_d3af9d4c.png  
      inflating: walk_or_run_test/test/walk/walk_e46826c9.png  
      inflating: walk_or_run_test/test/walk/walk_e47417b0.png  
      inflating: walk_or_run_test/test/walk/walk_e5fb5c62.png  
      inflating: walk_or_run_test/test/walk/walk_e9ac206a.png  
      inflating: walk_or_run_test/test/walk/walk_ee0ee9a8.png  
      inflating: walk_or_run_test/test/walk/walk_f3db2268.png  
      inflating: walk_or_run_test/test/walk/walk_f41d20a0.png  
      inflating: walk_or_run_test/test/walk/walk_f5d58cea.png  
      inflating: walk_or_run_test/test/walk/walk_f8b5d2db.png  
      inflating: walk_or_run_test/test/walk/walk_f96e47a5.png  
      inflating: walk_or_run_test/test/walk/walk_fc359360.png  
      inflating: walk_or_run_test/test/walk/walk_fe9e5656.png  
      inflating: walk_or_run_train/train/run/run_00061c18.png  
      inflating: walk_or_run_train/train/run/run_01d134fc.png  
      inflating: walk_or_run_train/train/run/run_021a5686.png  
      inflating: walk_or_run_train/train/run/run_033697b0.png  
      inflating: walk_or_run_train/train/run/run_04b620cc.png  
      inflating: walk_or_run_train/train/run/run_0648da3d.png  
      inflating: walk_or_run_train/train/run/run_07df7b55.png  
      inflating: walk_or_run_train/train/run/run_0a9284fb.png  
      inflating: walk_or_run_train/train/run/run_0aa1d404.png  
      inflating: walk_or_run_train/train/run/run_0abc30f8.png  
      inflating: walk_or_run_train/train/run/run_0b56f527.png  
      inflating: walk_or_run_train/train/run/run_0b9180f4.png  
      inflating: walk_or_run_train/train/run/run_0c3ec7f1.png  
      inflating: walk_or_run_train/train/run/run_0c537846.png  
      inflating: walk_or_run_train/train/run/run_0e440581.png  
      inflating: walk_or_run_train/train/run/run_11fe555f.png  
      inflating: walk_or_run_train/train/run/run_1295a1d6.png  
      inflating: walk_or_run_train/train/run/run_143a570e.png  
      inflating: walk_or_run_train/train/run/run_144502d4.png  
      inflating: walk_or_run_train/train/run/run_14e9ec67.png  
      inflating: walk_or_run_train/train/run/run_15b27eec.png  
      inflating: walk_or_run_train/train/run/run_1685fb88.png  
      inflating: walk_or_run_train/train/run/run_16e76f02.png  
      inflating: walk_or_run_train/train/run/run_1707e727.png  
      inflating: walk_or_run_train/train/run/run_18928876.png  
      inflating: walk_or_run_train/train/run/run_18e7ef78.png  
      inflating: walk_or_run_train/train/run/run_191f334f.png  
      inflating: walk_or_run_train/train/run/run_1b8d7e5a.png  
      inflating: walk_or_run_train/train/run/run_1c7ed2a1.png  
      inflating: walk_or_run_train/train/run/run_1cb217e6.png  
      inflating: walk_or_run_train/train/run/run_1ee52c2b.png  
      inflating: walk_or_run_train/train/run/run_1fed681b.png  
      inflating: walk_or_run_train/train/run/run_20066d30.png  
      inflating: walk_or_run_train/train/run/run_204c2085.png  
      inflating: walk_or_run_train/train/run/run_210deb18.png  
      inflating: walk_or_run_train/train/run/run_2473cdab.png  
      inflating: walk_or_run_train/train/run/run_24e1244a.png  
      inflating: walk_or_run_train/train/run/run_24ece0c7.png  
      inflating: walk_or_run_train/train/run/run_255f33ed.png  
      inflating: walk_or_run_train/train/run/run_297cf8ba.png  
      inflating: walk_or_run_train/train/run/run_2995f395.png  
      inflating: walk_or_run_train/train/run/run_2b90c677.png  
      inflating: walk_or_run_train/train/run/run_2b97ed11.png  
      inflating: walk_or_run_train/train/run/run_2be0098a.png  
      inflating: walk_or_run_train/train/run/run_2d12d5b6.png  
      inflating: walk_or_run_train/train/run/run_2d986c74.png  
      inflating: walk_or_run_train/train/run/run_2e0e3392.png  
      inflating: walk_or_run_train/train/run/run_2ea5f77f.png  
      inflating: walk_or_run_train/train/run/run_2fe30810.png  
      inflating: walk_or_run_train/train/run/run_3091645b.png  
      inflating: walk_or_run_train/train/run/run_328ff7db.png  
      inflating: walk_or_run_train/train/run/run_330192fb.png  
      inflating: walk_or_run_train/train/run/run_35b521e4.png  
      inflating: walk_or_run_train/train/run/run_3762a365.png  
      inflating: walk_or_run_train/train/run/run_38ea9029.png  
      inflating: walk_or_run_train/train/run/run_3955c405.png  
      inflating: walk_or_run_train/train/run/run_39c1794d.png  
      inflating: walk_or_run_train/train/run/run_3a05ce65.png  
      inflating: walk_or_run_train/train/run/run_3ce0ddc5.png  
      inflating: walk_or_run_train/train/run/run_3d0b86f8.png  
      inflating: walk_or_run_train/train/run/run_3d4f6106.png  
      inflating: walk_or_run_train/train/run/run_3dedf07b.png  
      inflating: walk_or_run_train/train/run/run_3e5fe702.png  
      inflating: walk_or_run_train/train/run/run_3f199eca.png  
      inflating: walk_or_run_train/train/run/run_3fec04dc.png  
      inflating: walk_or_run_train/train/run/run_40307acd.png  
      inflating: walk_or_run_train/train/run/run_40b7456d.png  
      inflating: walk_or_run_train/train/run/run_40c73a68.png  
      inflating: walk_or_run_train/train/run/run_41aea8d8.png  
      inflating: walk_or_run_train/train/run/run_45c9b887.png  
      inflating: walk_or_run_train/train/run/run_46633e2b.png  
      inflating: walk_or_run_train/train/run/run_47cd5df2.png  
      inflating: walk_or_run_train/train/run/run_48c87094.png  
      inflating: walk_or_run_train/train/run/run_494e5df1.png  
      inflating: walk_or_run_train/train/run/run_4aa38519.png  
      inflating: walk_or_run_train/train/run/run_4b0b24dd.png  
      inflating: walk_or_run_train/train/run/run_4b305888.png  
      inflating: walk_or_run_train/train/run/run_4cceff3c.png  
      inflating: walk_or_run_train/train/run/run_4cff1e1f.png  
      inflating: walk_or_run_train/train/run/run_4e1b41e3.png  
      inflating: walk_or_run_train/train/run/run_4ed46b07.png  
      inflating: walk_or_run_train/train/run/run_4ed4e4fd.png  
      inflating: walk_or_run_train/train/run/run_4f9615de.png  
      inflating: walk_or_run_train/train/run/run_52068d3d.png  
      inflating: walk_or_run_train/train/run/run_5230fa57.png  
      inflating: walk_or_run_train/train/run/run_52730879.png  
      inflating: walk_or_run_train/train/run/run_52d07e35.png  
      inflating: walk_or_run_train/train/run/run_54017fa7.png  
      inflating: walk_or_run_train/train/run/run_547819db.png  
      inflating: walk_or_run_train/train/run/run_55c2b0a0.png  
      inflating: walk_or_run_train/train/run/run_55c45dbc.png  
      inflating: walk_or_run_train/train/run/run_55d71327.png  
      inflating: walk_or_run_train/train/run/run_55fe1de2.png  
      inflating: walk_or_run_train/train/run/run_598fc449.png  
      inflating: walk_or_run_train/train/run/run_59c4eb7c.png  
      inflating: walk_or_run_train/train/run/run_59e9ef28.png  
      inflating: walk_or_run_train/train/run/run_5b7ad000.png  
      inflating: walk_or_run_train/train/run/run_5d34f556.png  
      inflating: walk_or_run_train/train/run/run_5d8b0822.png  
      inflating: walk_or_run_train/train/run/run_5efc245a.png  
      inflating: walk_or_run_train/train/run/run_5fb28fe0.png  
      inflating: walk_or_run_train/train/run/run_5fc270cc.png  
      inflating: walk_or_run_train/train/run/run_60b9d6a4.png  
      inflating: walk_or_run_train/train/run/run_61099f61.png  
      inflating: walk_or_run_train/train/run/run_61239b1c.png  
      inflating: walk_or_run_train/train/run/run_61f346be.png  
      inflating: walk_or_run_train/train/run/run_62b8f78c.png  
      inflating: walk_or_run_train/train/run/run_62e9eaa4.png  
      inflating: walk_or_run_train/train/run/run_639f8a54.png  
      inflating: walk_or_run_train/train/run/run_63f01c69.png  
      inflating: walk_or_run_train/train/run/run_644dcb17.png  
      inflating: walk_or_run_train/train/run/run_6461a104.png  
      inflating: walk_or_run_train/train/run/run_68175913.png  
      inflating: walk_or_run_train/train/run/run_6895b8bd.png  
      inflating: walk_or_run_train/train/run/run_6999e03d.png  
      inflating: walk_or_run_train/train/run/run_69b8e96f.png  
      inflating: walk_or_run_train/train/run/run_6c418bb1.png  
      inflating: walk_or_run_train/train/run/run_6c7aa90f.png  
      inflating: walk_or_run_train/train/run/run_6d0a6b9f.png  
      inflating: walk_or_run_train/train/run/run_6f2b4633.png  
      inflating: walk_or_run_train/train/run/run_6f6c225d.png  
      inflating: walk_or_run_train/train/run/run_6f7aea4d.png  
      inflating: walk_or_run_train/train/run/run_70982d21.png  
      inflating: walk_or_run_train/train/run/run_71f336c4.png  
      inflating: walk_or_run_train/train/run/run_73368ef1.png  
      inflating: walk_or_run_train/train/run/run_734250c1.png  
      inflating: walk_or_run_train/train/run/run_742330c2.png  
      inflating: walk_or_run_train/train/run/run_75f8dce5.png  
      inflating: walk_or_run_train/train/run/run_764d8fe3.png  
      inflating: walk_or_run_train/train/run/run_770667c3.png  
      inflating: walk_or_run_train/train/run/run_772fbfd8.png  
      inflating: walk_or_run_train/train/run/run_7780e355.png  
      inflating: walk_or_run_train/train/run/run_7a3481ed.png  
      inflating: walk_or_run_train/train/run/run_7aa2a454.png  
      inflating: walk_or_run_train/train/run/run_7b1828d4.png  
      inflating: walk_or_run_train/train/run/run_7d99207b.png  
      inflating: walk_or_run_train/train/run/run_7f01559d.png  
      inflating: walk_or_run_train/train/run/run_7f113d88.png  
      inflating: walk_or_run_train/train/run/run_7f825b14.png  
      inflating: walk_or_run_train/train/run/run_80f77122.png  
      inflating: walk_or_run_train/train/run/run_8196e1ad.png  
      inflating: walk_or_run_train/train/run/run_81dff100.png  
      inflating: walk_or_run_train/train/run/run_83b044ab.png  
      inflating: walk_or_run_train/train/run/run_83b2f9ae.png  
      inflating: walk_or_run_train/train/run/run_83bdaadc.png  
      inflating: walk_or_run_train/train/run/run_83e48409.png  
      inflating: walk_or_run_train/train/run/run_84deac5c.png  
      inflating: walk_or_run_train/train/run/run_851921ec.png  
      inflating: walk_or_run_train/train/run/run_862c9429.png  
      inflating: walk_or_run_train/train/run/run_87a18e26.png  
      inflating: walk_or_run_train/train/run/run_8819bef9.png  
      inflating: walk_or_run_train/train/run/run_883029d6.png  
      inflating: walk_or_run_train/train/run/run_883d4424.png  
      inflating: walk_or_run_train/train/run/run_89376903.png  
      inflating: walk_or_run_train/train/run/run_8977da10.png  
      inflating: walk_or_run_train/train/run/run_8a235ba7.png  
      inflating: walk_or_run_train/train/run/run_8aa98f7d.png  
      inflating: walk_or_run_train/train/run/run_8abfd70d.png  
      inflating: walk_or_run_train/train/run/run_8bdbc7bb.png  
      inflating: walk_or_run_train/train/run/run_8bf6e7b3.png  
      inflating: walk_or_run_train/train/run/run_8d4281d6.png  
      inflating: walk_or_run_train/train/run/run_8ddd68a7.png  
      inflating: walk_or_run_train/train/run/run_8e6e8cad.png  
      inflating: walk_or_run_train/train/run/run_8f022f03.png  
      inflating: walk_or_run_train/train/run/run_8f2595c0.png  
      inflating: walk_or_run_train/train/run/run_8f90548c.png  
      inflating: walk_or_run_train/train/run/run_8fd1a047.png  
      inflating: walk_or_run_train/train/run/run_90b89869.png  
      inflating: walk_or_run_train/train/run/run_918ec096.png  
      inflating: walk_or_run_train/train/run/run_93580243.png  
      inflating: walk_or_run_train/train/run/run_93829bc1.png  
      inflating: walk_or_run_train/train/run/run_944d070d.png  
      inflating: walk_or_run_train/train/run/run_94ce1c88.png  
      inflating: walk_or_run_train/train/run/run_96a67345.png  
      inflating: walk_or_run_train/train/run/run_975a2542.png  
      inflating: walk_or_run_train/train/run/run_97ac205f.png  
      inflating: walk_or_run_train/train/run/run_984288e6.png  
      inflating: walk_or_run_train/train/run/run_9a0e01be.png  
      inflating: walk_or_run_train/train/run/run_9a489899.png  
      inflating: walk_or_run_train/train/run/run_9a508437.png  
      inflating: walk_or_run_train/train/run/run_9b569038.png  
      inflating: walk_or_run_train/train/run/run_9bb52826.png  
      inflating: walk_or_run_train/train/run/run_9c1bc289.png  
      inflating: walk_or_run_train/train/run/run_9c43e593.png  
      inflating: walk_or_run_train/train/run/run_9d046012.png  
      inflating: walk_or_run_train/train/run/run_9d1e6d5f.png  
      inflating: walk_or_run_train/train/run/run_9d315f83.png  
      inflating: walk_or_run_train/train/run/run_9da2d846.png  
      inflating: walk_or_run_train/train/run/run_9e458faa.png  
      inflating: walk_or_run_train/train/run/run_9e91c347.png  
      inflating: walk_or_run_train/train/run/run_9ef7e728.png  
      inflating: walk_or_run_train/train/run/run_a0775979.png  
      inflating: walk_or_run_train/train/run/run_a1d31c97.png  
      inflating: walk_or_run_train/train/run/run_a1f35e68.png  
      inflating: walk_or_run_train/train/run/run_a2c7f250.png  
      inflating: walk_or_run_train/train/run/run_a379f139.png  
      inflating: walk_or_run_train/train/run/run_a384f113.png  
      inflating: walk_or_run_train/train/run/run_a3f792b8.png  
      inflating: walk_or_run_train/train/run/run_a4516cad.png  
      inflating: walk_or_run_train/train/run/run_a4a252f7.png  
      inflating: walk_or_run_train/train/run/run_a5931003.png  
      inflating: walk_or_run_train/train/run/run_a75e3155.png  
      inflating: walk_or_run_train/train/run/run_a87266f0.png  
      inflating: walk_or_run_train/train/run/run_a8f6d9d2.png  
      inflating: walk_or_run_train/train/run/run_a9232227.png  
      inflating: walk_or_run_train/train/run/run_a925bb54.png  
      inflating: walk_or_run_train/train/run/run_a9fdecbc.png  
      inflating: walk_or_run_train/train/run/run_ab05d1a6.png  
      inflating: walk_or_run_train/train/run/run_aeeb802c.png  
      inflating: walk_or_run_train/train/run/run_af2b304c.png  
      inflating: walk_or_run_train/train/run/run_aff53edc.png  
      inflating: walk_or_run_train/train/run/run_b00ca548.png  
      inflating: walk_or_run_train/train/run/run_b0bb739f.png  
      inflating: walk_or_run_train/train/run/run_b10e794f.png  
      inflating: walk_or_run_train/train/run/run_b16ac748.png  
      inflating: walk_or_run_train/train/run/run_b19883d1.png  
      inflating: walk_or_run_train/train/run/run_b540ae91.png  
      inflating: walk_or_run_train/train/run/run_b7d17192.png  
      inflating: walk_or_run_train/train/run/run_b8c21968.png  
      inflating: walk_or_run_train/train/run/run_b8c47056.png  
      inflating: walk_or_run_train/train/run/run_b97ca439.png  
      inflating: walk_or_run_train/train/run/run_b9a4a52f.png  
      inflating: walk_or_run_train/train/run/run_b9ac5c5b.png  
      inflating: walk_or_run_train/train/run/run_b9f98417.png  
      inflating: walk_or_run_train/train/run/run_ba6da104.png  
      inflating: walk_or_run_train/train/run/run_bbea42fb.png  
      inflating: walk_or_run_train/train/run/run_c0b15735.png  
      inflating: walk_or_run_train/train/run/run_c101b372.png  
      inflating: walk_or_run_train/train/run/run_c146dc32.png  
      inflating: walk_or_run_train/train/run/run_c2ed65e1.png  
      inflating: walk_or_run_train/train/run/run_c3587ef1.png  
      inflating: walk_or_run_train/train/run/run_c47d3d4d.png  
      inflating: walk_or_run_train/train/run/run_c51bd5ca.png  
      inflating: walk_or_run_train/train/run/run_c629b320.png  
      inflating: walk_or_run_train/train/run/run_c6aaa9c6.png  
      inflating: walk_or_run_train/train/run/run_c6c7c567.png  
      inflating: walk_or_run_train/train/run/run_c6e0f275.png  
      inflating: walk_or_run_train/train/run/run_c8410cce.png  
      inflating: walk_or_run_train/train/run/run_c871e8c1.png  
      inflating: walk_or_run_train/train/run/run_c88567f0.png  
      inflating: walk_or_run_train/train/run/run_c953b99b.png  
      inflating: walk_or_run_train/train/run/run_c99641ec.png  
      inflating: walk_or_run_train/train/run/run_ca2b5bf0.png  
      inflating: walk_or_run_train/train/run/run_ca877e3c.png  
      inflating: walk_or_run_train/train/run/run_caad1aa4.png  
      inflating: walk_or_run_train/train/run/run_cb681209.png  
      inflating: walk_or_run_train/train/run/run_cb79a46b.png  
      inflating: walk_or_run_train/train/run/run_cbe60c9d.png  
      inflating: walk_or_run_train/train/run/run_cd626cb9.png  
      inflating: walk_or_run_train/train/run/run_cd958ed9.png  
      inflating: walk_or_run_train/train/run/run_cf693ba3.png  
      inflating: walk_or_run_train/train/run/run_cf8c3366.png  
      inflating: walk_or_run_train/train/run/run_d054c079.png  
      inflating: walk_or_run_train/train/run/run_d15b56a6.png  
      inflating: walk_or_run_train/train/run/run_d25159e5.png  
      inflating: walk_or_run_train/train/run/run_d2704ea9.png  
      inflating: walk_or_run_train/train/run/run_d29f89b3.png  
      inflating: walk_or_run_train/train/run/run_d3c49a0c.png  
      inflating: walk_or_run_train/train/run/run_d5fae015.png  
      inflating: walk_or_run_train/train/run/run_d7749f0b.png  
      inflating: walk_or_run_train/train/run/run_d7f5294f.png  
      inflating: walk_or_run_train/train/run/run_d874901d.png  
      inflating: walk_or_run_train/train/run/run_d886365d.png  
      inflating: walk_or_run_train/train/run/run_d8bd5a21.png  
      inflating: walk_or_run_train/train/run/run_db6121d5.png  
      inflating: walk_or_run_train/train/run/run_dc0dee15.png  
      inflating: walk_or_run_train/train/run/run_dc881a13.png  
      inflating: walk_or_run_train/train/run/run_dcee0493.png  
      inflating: walk_or_run_train/train/run/run_e0ea1386.png  
      inflating: walk_or_run_train/train/run/run_e1e80bd8.png  
      inflating: walk_or_run_train/train/run/run_e253af3b.png  
      inflating: walk_or_run_train/train/run/run_e429932e.png  
      inflating: walk_or_run_train/train/run/run_e7a2eb00.png  
      inflating: walk_or_run_train/train/run/run_e959b9fe.png  
      inflating: walk_or_run_train/train/run/run_eb25643b.png  
      inflating: walk_or_run_train/train/run/run_eba4867c.png  
      inflating: walk_or_run_train/train/run/run_ecc49c30.png  
      inflating: walk_or_run_train/train/run/run_ecd444ca.png  
      inflating: walk_or_run_train/train/run/run_ed5d701b.png  
      inflating: walk_or_run_train/train/run/run_ed8f3677.png  
      inflating: walk_or_run_train/train/run/run_ee024937.png  
      inflating: walk_or_run_train/train/run/run_ef3ed882.png  
      inflating: walk_or_run_train/train/run/run_f13a6da3.png  
      inflating: walk_or_run_train/train/run/run_f1a0e3b4.png  
      inflating: walk_or_run_train/train/run/run_f1b588f2.png  
      inflating: walk_or_run_train/train/run/run_f2a51a25.png  
      inflating: walk_or_run_train/train/run/run_f335e9dd.png  
      inflating: walk_or_run_train/train/run/run_f35a94a8.png  
      inflating: walk_or_run_train/train/run/run_f3de515f.png  
      inflating: walk_or_run_train/train/run/run_f470a9f7.png  
      inflating: walk_or_run_train/train/run/run_f5bd3365.png  
      inflating: walk_or_run_train/train/run/run_f71fab56.png  
      inflating: walk_or_run_train/train/run/run_f7993f33.png  
      inflating: walk_or_run_train/train/run/run_f8f8f0c7.png  
      inflating: walk_or_run_train/train/run/run_f9009957.png  
      inflating: walk_or_run_train/train/run/run_fa283738.png  
      inflating: walk_or_run_train/train/run/run_fa9389ef.png  
      inflating: walk_or_run_train/train/run/run_fcfacd5a.png  
      inflating: walk_or_run_train/train/run/run_ff531626.png  
      inflating: walk_or_run_train/train/walk/walk_00e3d982.png  
      inflating: walk_or_run_train/train/walk/walk_0173e50c.png  
      inflating: walk_or_run_train/train/walk/walk_02852997.png  
      inflating: walk_or_run_train/train/walk/walk_030ed8f2.png  
      inflating: walk_or_run_train/train/walk/walk_031ff1f1.png  
      inflating: walk_or_run_train/train/walk/walk_03b615e2.png  
      inflating: walk_or_run_train/train/walk/walk_0475ca9c.png  
      inflating: walk_or_run_train/train/walk/walk_048ab4b2.png  
      inflating: walk_or_run_train/train/walk/walk_054096d9.png  
      inflating: walk_or_run_train/train/walk/walk_078a937d.png  
      inflating: walk_or_run_train/train/walk/walk_0889bc7d.png  
      inflating: walk_or_run_train/train/walk/walk_0ab43cab.png  
      inflating: walk_or_run_train/train/walk/walk_0bae5a2f.png  
      inflating: walk_or_run_train/train/walk/walk_0f839625.png  
      inflating: walk_or_run_train/train/walk/walk_10fd9474.png  
      inflating: walk_or_run_train/train/walk/walk_113e1597.png  
      inflating: walk_or_run_train/train/walk/walk_122d558a.png  
      inflating: walk_or_run_train/train/walk/walk_12e8961b.png  
      inflating: walk_or_run_train/train/walk/walk_12f08de0.png  
      inflating: walk_or_run_train/train/walk/walk_157cb0b7.png  
      inflating: walk_or_run_train/train/walk/walk_1616359c.png  
      inflating: walk_or_run_train/train/walk/walk_16acbd83.png  
      inflating: walk_or_run_train/train/walk/walk_17cfba9a.png  
      inflating: walk_or_run_train/train/walk/walk_1859f826.png  
      inflating: walk_or_run_train/train/walk/walk_18659c3c.png  
      inflating: walk_or_run_train/train/walk/walk_1893c656.png  
      inflating: walk_or_run_train/train/walk/walk_18ffe9d5.png  
      inflating: walk_or_run_train/train/walk/walk_1ac1d89f.png  
      inflating: walk_or_run_train/train/walk/walk_1b7a7666.png  
      inflating: walk_or_run_train/train/walk/walk_1bf04186.png  
      inflating: walk_or_run_train/train/walk/walk_1ca687c9.png  
      inflating: walk_or_run_train/train/walk/walk_1caabdd0.png  
      inflating: walk_or_run_train/train/walk/walk_1d81a125.png  
      inflating: walk_or_run_train/train/walk/walk_1e8c7768.png  
      inflating: walk_or_run_train/train/walk/walk_1ee72c37.png  
      inflating: walk_or_run_train/train/walk/walk_1eee9821.png  
      inflating: walk_or_run_train/train/walk/walk_20015ab9.png  
      inflating: walk_or_run_train/train/walk/walk_236a0ed2.png  
      inflating: walk_or_run_train/train/walk/walk_237eafc4.png  
      inflating: walk_or_run_train/train/walk/walk_2383d608.png  
      inflating: walk_or_run_train/train/walk/walk_23d11643.png  
      inflating: walk_or_run_train/train/walk/walk_2425f711.png  
      inflating: walk_or_run_train/train/walk/walk_246c28c0.png  
      inflating: walk_or_run_train/train/walk/walk_24f3368c.png  
      inflating: walk_or_run_train/train/walk/walk_2750f643.png  
      inflating: walk_or_run_train/train/walk/walk_27d8ccfa.png  
      inflating: walk_or_run_train/train/walk/walk_2850aef7.png  
      inflating: walk_or_run_train/train/walk/walk_2894196b.png  
      inflating: walk_or_run_train/train/walk/walk_2994b653.png  
      inflating: walk_or_run_train/train/walk/walk_2a7614cd.png  
      inflating: walk_or_run_train/train/walk/walk_2be55839.png  
      inflating: walk_or_run_train/train/walk/walk_2f2418ab.png  
      inflating: walk_or_run_train/train/walk/walk_30dc570f.png  
      inflating: walk_or_run_train/train/walk/walk_3140b0d5.png  
      inflating: walk_or_run_train/train/walk/walk_31e77b40.png  
      inflating: walk_or_run_train/train/walk/walk_32fa46b8.png  
      inflating: walk_or_run_train/train/walk/walk_3398e2a7.png  
      inflating: walk_or_run_train/train/walk/walk_346fe00e.png  
      inflating: walk_or_run_train/train/walk/walk_3579891f.png  
      inflating: walk_or_run_train/train/walk/walk_358e1873.png  
      inflating: walk_or_run_train/train/walk/walk_361bc465.png  
      inflating: walk_or_run_train/train/walk/walk_365dba1a.png  
      inflating: walk_or_run_train/train/walk/walk_370001cd.png  
      inflating: walk_or_run_train/train/walk/walk_3737e542.png  
      inflating: walk_or_run_train/train/walk/walk_373f719c.png  
      inflating: walk_or_run_train/train/walk/walk_37b400d6.png  
      inflating: walk_or_run_train/train/walk/walk_39237fdd.png  
      inflating: walk_or_run_train/train/walk/walk_3e3a33d8.png  
      inflating: walk_or_run_train/train/walk/walk_3e4348dc.png  
      inflating: walk_or_run_train/train/walk/walk_3ee5b835.png  
      inflating: walk_or_run_train/train/walk/walk_3f4723b7.png  
      inflating: walk_or_run_train/train/walk/walk_3fa35227.png  
      inflating: walk_or_run_train/train/walk/walk_40446d44.png  
      inflating: walk_or_run_train/train/walk/walk_405ec40e.png  
      inflating: walk_or_run_train/train/walk/walk_40bbc0c2.png  
      inflating: walk_or_run_train/train/walk/walk_41eada3e.png  
      inflating: walk_or_run_train/train/walk/walk_42482c7b.png  
      inflating: walk_or_run_train/train/walk/walk_42574283.png  
      inflating: walk_or_run_train/train/walk/walk_438ba398.png  
      inflating: walk_or_run_train/train/walk/walk_4436d1e7.png  
      inflating: walk_or_run_train/train/walk/walk_451f5d5a.png  
      inflating: walk_or_run_train/train/walk/walk_474b6f9d.png  
      inflating: walk_or_run_train/train/walk/walk_47b25bd2.png  
      inflating: walk_or_run_train/train/walk/walk_48fc53bb.png  
      inflating: walk_or_run_train/train/walk/walk_49ac6f6e.png  
      inflating: walk_or_run_train/train/walk/walk_4b9cf2c0.png  
      inflating: walk_or_run_train/train/walk/walk_4e0263b4.png  
      inflating: walk_or_run_train/train/walk/walk_4e55afdc.png  
      inflating: walk_or_run_train/train/walk/walk_4ecc979c.png  
      inflating: walk_or_run_train/train/walk/walk_4f0c3d24.png  
      inflating: walk_or_run_train/train/walk/walk_4fa38ec0.png  
      inflating: walk_or_run_train/train/walk/walk_4fa48861.png  
      inflating: walk_or_run_train/train/walk/walk_4fef4038.png  
      inflating: walk_or_run_train/train/walk/walk_51a414fc.png  
      inflating: walk_or_run_train/train/walk/walk_52e727ef.png  
      inflating: walk_or_run_train/train/walk/walk_5389e1f2.png  
      inflating: walk_or_run_train/train/walk/walk_54fbf051.png  
      inflating: walk_or_run_train/train/walk/walk_55d8b174.png  
      inflating: walk_or_run_train/train/walk/walk_5af02106.png  
      inflating: walk_or_run_train/train/walk/walk_5b27f6db.png  
      inflating: walk_or_run_train/train/walk/walk_5b32f2d3.png  
      inflating: walk_or_run_train/train/walk/walk_5cc55431.png  
      inflating: walk_or_run_train/train/walk/walk_5d65ee63.png  
      inflating: walk_or_run_train/train/walk/walk_5e8aecbb.png  
      inflating: walk_or_run_train/train/walk/walk_600a4487.png  
      inflating: walk_or_run_train/train/walk/walk_603e8dd7.png  
      inflating: walk_or_run_train/train/walk/walk_609a670a.png  
      inflating: walk_or_run_train/train/walk/walk_60f2892f.png  
      inflating: walk_or_run_train/train/walk/walk_627904b1.png  
      inflating: walk_or_run_train/train/walk/walk_63ca2ca1.png  
      inflating: walk_or_run_train/train/walk/walk_63cc78bd.png  
      inflating: walk_or_run_train/train/walk/walk_6510401f.png  
      inflating: walk_or_run_train/train/walk/walk_656e1a93.png  
      inflating: walk_or_run_train/train/walk/walk_658605de.png  
      inflating: walk_or_run_train/train/walk/walk_68055051.png  
      inflating: walk_or_run_train/train/walk/walk_68cc7990.png  
      inflating: walk_or_run_train/train/walk/walk_68e822d3.png  
      inflating: walk_or_run_train/train/walk/walk_6905c3c5.png  
      inflating: walk_or_run_train/train/walk/walk_69918fb3.png  
      inflating: walk_or_run_train/train/walk/walk_699d0d2d.png  
      inflating: walk_or_run_train/train/walk/walk_69c2893c.png  
      inflating: walk_or_run_train/train/walk/walk_6b7a0ad9.png  
      inflating: walk_or_run_train/train/walk/walk_6b9f7042.png  
      inflating: walk_or_run_train/train/walk/walk_6c44ed82.png  
      inflating: walk_or_run_train/train/walk/walk_6d353a12.png  
      inflating: walk_or_run_train/train/walk/walk_719de51d.png  
      inflating: walk_or_run_train/train/walk/walk_7254d2a3.png  
      inflating: walk_or_run_train/train/walk/walk_72b9dc9c.png  
      inflating: walk_or_run_train/train/walk/walk_74774e78.png  
      inflating: walk_or_run_train/train/walk/walk_7494b444.png  
      inflating: walk_or_run_train/train/walk/walk_74a058a4.png  
      inflating: walk_or_run_train/train/walk/walk_74feca8e.png  
      inflating: walk_or_run_train/train/walk/walk_7579d335.png  
      inflating: walk_or_run_train/train/walk/walk_76210243.png  
      inflating: walk_or_run_train/train/walk/walk_7624aed7.png  
      inflating: walk_or_run_train/train/walk/walk_77ab8966.png  
      inflating: walk_or_run_train/train/walk/walk_78991116.png  
      inflating: walk_or_run_train/train/walk/walk_791ae960.png  
      inflating: walk_or_run_train/train/walk/walk_7999e5b2.png  
      inflating: walk_or_run_train/train/walk/walk_7a6be96a.png  
      inflating: walk_or_run_train/train/walk/walk_7b0458fd.png  
      inflating: walk_or_run_train/train/walk/walk_7b1394c7.png  
      inflating: walk_or_run_train/train/walk/walk_7b238d44.png  
      inflating: walk_or_run_train/train/walk/walk_7b344bdd.png  
      inflating: walk_or_run_train/train/walk/walk_7c7c0fbb.png  
      inflating: walk_or_run_train/train/walk/walk_7ce332ae.png  
      inflating: walk_or_run_train/train/walk/walk_7d2756ee.png  
      inflating: walk_or_run_train/train/walk/walk_7ed35c7e.png  
      inflating: walk_or_run_train/train/walk/walk_7f2bb059.png  
      inflating: walk_or_run_train/train/walk/walk_8000cf22.png  
      inflating: walk_or_run_train/train/walk/walk_80279bc5.png  
      inflating: walk_or_run_train/train/walk/walk_82c3b0f9.png  
      inflating: walk_or_run_train/train/walk/walk_82cdb83e.png  
      inflating: walk_or_run_train/train/walk/walk_82eec80c.png  
      inflating: walk_or_run_train/train/walk/walk_8404e089.png  
      inflating: walk_or_run_train/train/walk/walk_84550a2e.png  
      inflating: walk_or_run_train/train/walk/walk_8489e345.png  
      inflating: walk_or_run_train/train/walk/walk_84aaae81.png  
      inflating: walk_or_run_train/train/walk/walk_86c260a4.png  
      inflating: walk_or_run_train/train/walk/walk_87187f17.png  
      inflating: walk_or_run_train/train/walk/walk_879d83fd.png  
      inflating: walk_or_run_train/train/walk/walk_897205e8.png  
      inflating: walk_or_run_train/train/walk/walk_8c005c50.png  
      inflating: walk_or_run_train/train/walk/walk_8c6d5789.png  
      inflating: walk_or_run_train/train/walk/walk_8d129c64.png  
      inflating: walk_or_run_train/train/walk/walk_8e7c69fd.png  
      inflating: walk_or_run_train/train/walk/walk_8f232bfe.png  
      inflating: walk_or_run_train/train/walk/walk_8f76e0c5.png  
      inflating: walk_or_run_train/train/walk/walk_8f9d2347.png  
      inflating: walk_or_run_train/train/walk/walk_8fe30c6e.png  
      inflating: walk_or_run_train/train/walk/walk_9026d006.png  
      inflating: walk_or_run_train/train/walk/walk_9095121e.png  
      inflating: walk_or_run_train/train/walk/walk_913c92fb.png  
      inflating: walk_or_run_train/train/walk/walk_92d877cf.png  
      inflating: walk_or_run_train/train/walk/walk_93032ff5.png  
      inflating: walk_or_run_train/train/walk/walk_9401b98d.png  
      inflating: walk_or_run_train/train/walk/walk_95ecf6de.png  
      inflating: walk_or_run_train/train/walk/walk_991d1b3f.png  
      inflating: walk_or_run_train/train/walk/walk_9974f8ad.png  
      inflating: walk_or_run_train/train/walk/walk_9abf671a.png  
      inflating: walk_or_run_train/train/walk/walk_9d27ec88.png  
      inflating: walk_or_run_train/train/walk/walk_9de03315.png  
      inflating: walk_or_run_train/train/walk/walk_9f099ade.png  
      inflating: walk_or_run_train/train/walk/walk_9ffd8fb1.png  
      inflating: walk_or_run_train/train/walk/walk_a0f26e42.png  
      inflating: walk_or_run_train/train/walk/walk_a1083271.png  
      inflating: walk_or_run_train/train/walk/walk_a1b1aea5.png  
      inflating: walk_or_run_train/train/walk/walk_a21fd782.png  
      inflating: walk_or_run_train/train/walk/walk_a2709922.png  
      inflating: walk_or_run_train/train/walk/walk_a285f87e.png  
      inflating: walk_or_run_train/train/walk/walk_a2f51f74.png  
      inflating: walk_or_run_train/train/walk/walk_a39076be.png  
      inflating: walk_or_run_train/train/walk/walk_a4a95c7b.png  
      inflating: walk_or_run_train/train/walk/walk_a4b5e93c.png  
      inflating: walk_or_run_train/train/walk/walk_a6023e8c.png  
      inflating: walk_or_run_train/train/walk/walk_a66b1744.png  
      inflating: walk_or_run_train/train/walk/walk_a66c0848.png  
      inflating: walk_or_run_train/train/walk/walk_a81a8fe0.png  
      inflating: walk_or_run_train/train/walk/walk_a8710352.png  
      inflating: walk_or_run_train/train/walk/walk_a88e671b.png  
      inflating: walk_or_run_train/train/walk/walk_aaac4c96.png  
      inflating: walk_or_run_train/train/walk/walk_ab3edbdf.png  
      inflating: walk_or_run_train/train/walk/walk_adf57a56.png  
      inflating: walk_or_run_train/train/walk/walk_ae4f1eb9.png  
      inflating: walk_or_run_train/train/walk/walk_aedc6a40.png  
      inflating: walk_or_run_train/train/walk/walk_aef9a83e.png  
      inflating: walk_or_run_train/train/walk/walk_b0a96e8b.png  
      inflating: walk_or_run_train/train/walk/walk_b0aba01b.png  
      inflating: walk_or_run_train/train/walk/walk_b10e28ab.png  
      inflating: walk_or_run_train/train/walk/walk_b1501c04.png  
      inflating: walk_or_run_train/train/walk/walk_b19671c7.png  
      inflating: walk_or_run_train/train/walk/walk_b24adc2f.png  
      inflating: walk_or_run_train/train/walk/walk_b3870452.png  
      inflating: walk_or_run_train/train/walk/walk_b52883d8.png  
      inflating: walk_or_run_train/train/walk/walk_b92fefe1.png  
      inflating: walk_or_run_train/train/walk/walk_b93ae0dc.png  
      inflating: walk_or_run_train/train/walk/walk_b9975603.png  
      inflating: walk_or_run_train/train/walk/walk_b9d36ab6.png  
      inflating: walk_or_run_train/train/walk/walk_ba1fb7d6.png  
      inflating: walk_or_run_train/train/walk/walk_bb68114b.png  
      inflating: walk_or_run_train/train/walk/walk_bbc5c41c.png  
      inflating: walk_or_run_train/train/walk/walk_bcff2f38.png  
      inflating: walk_or_run_train/train/walk/walk_bdbe913a.png  
      inflating: walk_or_run_train/train/walk/walk_be0c5525.png  
      inflating: walk_or_run_train/train/walk/walk_be70a3b1.png  
      inflating: walk_or_run_train/train/walk/walk_becd3d3e.png  
      inflating: walk_or_run_train/train/walk/walk_bfc0b7fb.png  
      inflating: walk_or_run_train/train/walk/walk_bfd5b9cb.png  
      inflating: walk_or_run_train/train/walk/walk_c09ead7a.png  
      inflating: walk_or_run_train/train/walk/walk_c1861dbf.png  
      inflating: walk_or_run_train/train/walk/walk_c3301d4a.png  
      inflating: walk_or_run_train/train/walk/walk_c39ce2cd.png  
      inflating: walk_or_run_train/train/walk/walk_c465af86.png  
      inflating: walk_or_run_train/train/walk/walk_c4eec76f.png  
      inflating: walk_or_run_train/train/walk/walk_c9020c81.png  
      inflating: walk_or_run_train/train/walk/walk_c9f7ff26.png  
      inflating: walk_or_run_train/train/walk/walk_ca413bb5.png  
      inflating: walk_or_run_train/train/walk/walk_ca73bd6b.png  
      inflating: walk_or_run_train/train/walk/walk_cb0f02db.png  
      inflating: walk_or_run_train/train/walk/walk_cc36a8a4.png  
      inflating: walk_or_run_train/train/walk/walk_cc7ffa64.png  
      inflating: walk_or_run_train/train/walk/walk_ce047069.png  
      inflating: walk_or_run_train/train/walk/walk_cf049467.png  
      inflating: walk_or_run_train/train/walk/walk_cf1be335.png  
      inflating: walk_or_run_train/train/walk/walk_cf47b62f.png  
      inflating: walk_or_run_train/train/walk/walk_cf5d71e2.png  
      inflating: walk_or_run_train/train/walk/walk_cf63d904.png  
      inflating: walk_or_run_train/train/walk/walk_cff648b7.png  
      inflating: walk_or_run_train/train/walk/walk_d1bdb351.png  
      inflating: walk_or_run_train/train/walk/walk_d25d5fc4.png  
      inflating: walk_or_run_train/train/walk/walk_d2e63fe9.png  
      inflating: walk_or_run_train/train/walk/walk_d37870c7.png  
      inflating: walk_or_run_train/train/walk/walk_d44fe5fd.png  
      inflating: walk_or_run_train/train/walk/walk_d66372ee.png  
      inflating: walk_or_run_train/train/walk/walk_d77872d1.png  
      inflating: walk_or_run_train/train/walk/walk_d82f0ba5.png  
      inflating: walk_or_run_train/train/walk/walk_d83bc1a0.png  
      inflating: walk_or_run_train/train/walk/walk_d842dbed.png  
      inflating: walk_or_run_train/train/walk/walk_d8960d01.png  
      inflating: walk_or_run_train/train/walk/walk_d9848c10.png  
      inflating: walk_or_run_train/train/walk/walk_dbffae47.png  
      inflating: walk_or_run_train/train/walk/walk_dcbf1448.png  
      inflating: walk_or_run_train/train/walk/walk_dcc14183.png  
      inflating: walk_or_run_train/train/walk/walk_dd5631a7.png  
      inflating: walk_or_run_train/train/walk/walk_de665266.png  
      inflating: walk_or_run_train/train/walk/walk_deffae11.png  
      inflating: walk_or_run_train/train/walk/walk_e0971b24.png  
      inflating: walk_or_run_train/train/walk/walk_e0e29611.png  
      inflating: walk_or_run_train/train/walk/walk_e1675d0a.png  
      inflating: walk_or_run_train/train/walk/walk_e20f666b.png  
      inflating: walk_or_run_train/train/walk/walk_e2e4ae34.png  
      inflating: walk_or_run_train/train/walk/walk_e3ba54dd.png  
      inflating: walk_or_run_train/train/walk/walk_e3dd0f06.png  
      inflating: walk_or_run_train/train/walk/walk_e4fe74e3.png  
      inflating: walk_or_run_train/train/walk/walk_e6eb935f.png  
      inflating: walk_or_run_train/train/walk/walk_e8440bbe.png  
      inflating: walk_or_run_train/train/walk/walk_e913d3f9.png  
      inflating: walk_or_run_train/train/walk/walk_ea26a17f.png  
      inflating: walk_or_run_train/train/walk/walk_eb55a092.png  
      inflating: walk_or_run_train/train/walk/walk_ec153caa.png  
      inflating: walk_or_run_train/train/walk/walk_ee4e5f4f.png  
      inflating: walk_or_run_train/train/walk/walk_eea7516b.png  
      inflating: walk_or_run_train/train/walk/walk_f00ca35d.png  
      inflating: walk_or_run_train/train/walk/walk_f05c9540.png  
      inflating: walk_or_run_train/train/walk/walk_f0f1fc6a.png  
      inflating: walk_or_run_train/train/walk/walk_f18a1a50.png  
      inflating: walk_or_run_train/train/walk/walk_f1cb7d25.png  
      inflating: walk_or_run_train/train/walk/walk_f200c493.png  
      inflating: walk_or_run_train/train/walk/walk_f20f0703.png  
      inflating: walk_or_run_train/train/walk/walk_f34b22f0.png  
      inflating: walk_or_run_train/train/walk/walk_f411a00d.png  
      inflating: walk_or_run_train/train/walk/walk_f59ba6f2.png  
      inflating: walk_or_run_train/train/walk/walk_f5b1f023.png  
      inflating: walk_or_run_train/train/walk/walk_f640b242.png  
      inflating: walk_or_run_train/train/walk/walk_f6963aa6.png  
      inflating: walk_or_run_train/train/walk/walk_f6fe3b3a.png  
      inflating: walk_or_run_train/train/walk/walk_f7cb66cc.png  
      inflating: walk_or_run_train/train/walk/walk_f827add5.png  
      inflating: walk_or_run_train/train/walk/walk_fcf3fa51.png  
      inflating: walk_or_run_train/train/walk/walk_fe3afb34.png  
      inflating: walk_or_run_train/train/walk/walk_ff912309.png  


Our paths for train and test data directories


```python
train_dir = '/content/walk_or_run_train/train/'
test_dir = '/content/walk_or_run_test/test/'
```

Here we do some image preprocessing.We first normalize our data and then apply a transformation which crops the centre of the image.


```python
normalize = transforms.Normalize(
   mean=[0.485, 0.456, 0.406],
   std=[0.229, 0.224, 0.225]
)
ds_trans = transforms.Compose([transforms.Resize(224),
                               transforms.ToTensor(),
                               normalize])
```

Making our train and test data loader.
We just have to give the directory path to the torchivision ImageFolder it automatically labels the data and also applies tranformation and normalizes the data.

We give transform we defined earlier as an input.
The drop_last = *True* drops the last image data that does not fit in our image size.

For example:
If our total data is 100 images and our batch size is 32.Then our total batches will be 100//32 i.e 
100 = 32*3 +4. Here last four images will be dropped


```python
train_data = torchvision.datasets.ImageFolder(root=train_dir, transform=ds_trans)#giving our transformation as input with image data
train_data_loader = data.DataLoader(train_data, batch_size=4, shuffle=True,drop_last=True)#drop last drops the last images which does not fit in our batch size
test_data = torchvision.datasets.ImageFolder(root=test_dir, transform=ds_trans)
test_data_loader  = data.DataLoader(test_data, batch_size=4, shuffle=True,drop_last=True) 
```

Lets check how is our data


```python
w=10
h=10
fig=plt.figure(figsize=(8, 8))
columns = 4
rows = 5
count=0
for i,l in iter(train_data_loader):
  if count>11:
    break
  count+=1
  img = np.transpose(i[0].numpy(), (1, 2, 0))
  fig.add_subplot(rows, columns,count)
  plt.imshow(img)
plt.show(block=True)
```
![png](output_12_1.png)


We can see that the input images are not quite homogenous they are very different from each other.Some also have text in them.Some are just animated images of a cartoon runnning,still our model will performe good on this data.

### We define our resnet model here
1. We make an instance of resnet50 i.e resnet with 50 layers and we put *pretrained = True* which takes the parameters of already pretrianed resnet.
2. Here we are not trying to train the original resnet model. We will only train the last layer which we are adding.
3. We add the last layer that has 2 output neurons.
4. nn.Sequential let's us add a sequence of multiple layers which will execute one after another.
5. Then we use cuda() for faster GPU computing  

Freezing the parameters of resnet50 because we only want to train the last layer.We set *requires_grad = False* in this way the parameters of resnet50 will not change only the last *resnet.fc* layer will update their paramters.
We only have to fintune our network


```python
resnet = models.resnet50(pretrained=True)
# freeze all model parameters
for param in resnet.parameters():
    param.requires_grad = False

# new final layer with 16 classes
resnet.fc = nn.Sequential(
nn.Linear(2048,1024),
nn.ReLU(),
nn.BatchNorm1d(1024),
nn.Linear(1024,512),
nn.ReLU(),
nn.BatchNorm1d(512),
nn.Linear(512,128),
nn.ReLU(),
nn.BatchNorm1d(128),
nn.Linear(128,64),
nn.ReLU(),
nn.Linear(64,32),
nn.ReLU(),
nn.Linear(32,16),
nn.ReLU(),
nn.Linear(16,4),
nn.ReLU(),
nn.Linear(4,2),
nn.ReLU()
)
resnet = resnet.cuda()
```

Checking which layers of our model are to be trained. Which layers are supposed to update their parameters.


```python
feature_extract = True
#params_to_update = resnet.parameters()
print("Params to learn:")
if feature_extract:
    params_to_update = []
    for name,param in resnet.named_parameters():
        if param.requires_grad == True:#
            params_to_update.append(param)
            print("\t",name)
else:
    for name,param in resnet.named_parameters():
        if param.requires_grad == True:
            print("\t",name)
```

    Params to learn:
    	 fc.0.weight
    	 fc.0.bias
    	 fc.2.weight
    	 fc.2.bias
    	 fc.3.weight
    	 fc.3.bias
    	 fc.5.weight
    	 fc.5.bias
    	 fc.6.weight
    	 fc.6.bias
    	 fc.8.weight
    	 fc.8.bias
    	 fc.9.weight
    	 fc.9.bias
    	 fc.11.weight
    	 fc.11.bias
    	 fc.13.weight
    	 fc.13.bias
    	 fc.15.weight
    	 fc.15.bias
    	 fc.17.weight
    	 fc.17.bias


#### Defining our loss function and optimizer


```python
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(params_to_update,lr=0.00008)
```

### Training loop


```python
ll = []
resnet.train()
num_epoch = 30
for epoch in range(0,num_epoch):
  running_loss = 0.0
  running_corrects = 0.0
  c = 0 
  avg_acc=[]
  for images,labels in train_data_loader:
    inputs = images.cuda() #input image
    #labels = labels.reshape(-1,1)
    labels=labels.cuda() # target label
      #print(labels)
    c+=len(labels)
    optimizer.zero_grad()
    outputs = resnet(inputs) # model takes image as input and predicts an output
    loss = criterion(outputs,labels) # calculate loss
    _, preds = torch.max(outputs, 1) # predictions 
    loss.backward() #backprop
    optimizer.step()#optimizer steps 
    ll.append(loss.item())
    running_loss += loss.item()
    # accuracy checking and loss printing
    a = torch.sum(preds == labels.squeeze().data).item()
    running_corrects += torch.sum(preds == labels.squeeze().data).item()
    avg_acc.append((a/len(labels))*100)
  epoch_loss = running_loss/len(train_data_loader)
  epoch_acc = running_corrects/c
  print('{}/{} number of examples {} Average Acc {:.2f}'.format(epoch+1,num_epoch,c,(sum(avg_acc)/len(avg_acc))))
  print('{} Loss: {:.4f} Acc: {:.4f} Current Loss {:.3f}'.format("train", epoch_loss, epoch_acc,loss.item()))
```

    1/30 number of examples 600 Average Acc 49.83
    train Loss: 0.6969 Acc: 0.4983 Current Loss 0.746
    2/30 number of examples 600 Average Acc 51.33
    train Loss: 0.6839 Acc: 0.5133 Current Loss 0.648
    3/30 number of examples 600 Average Acc 68.83
    train Loss: 0.6637 Acc: 0.6883 Current Loss 0.619
    4/30 number of examples 600 Average Acc 75.33
    train Loss: 0.6446 Acc: 0.7533 Current Loss 0.631
    5/30 number of examples 600 Average Acc 78.67
    train Loss: 0.6328 Acc: 0.7867 Current Loss 0.648
    6/30 number of examples 600 Average Acc 76.83
    train Loss: 0.6270 Acc: 0.7683 Current Loss 0.595
    7/30 number of examples 600 Average Acc 75.83
    train Loss: 0.6133 Acc: 0.7583 Current Loss 0.582
    8/30 number of examples 600 Average Acc 79.67
    train Loss: 0.5824 Acc: 0.7967 Current Loss 0.492
    9/30 number of examples 600 Average Acc 80.00
    train Loss: 0.5502 Acc: 0.8000 Current Loss 0.602
    10/30 number of examples 600 Average Acc 77.00
    train Loss: 0.5640 Acc: 0.7700 Current Loss 0.520
    11/30 number of examples 600 Average Acc 79.17
    train Loss: 0.5534 Acc: 0.7917 Current Loss 0.462
    12/30 number of examples 600 Average Acc 80.33
    train Loss: 0.5449 Acc: 0.8033 Current Loss 0.459
    13/30 number of examples 600 Average Acc 81.50
    train Loss: 0.5227 Acc: 0.8150 Current Loss 0.372
    14/30 number of examples 600 Average Acc 78.33
    train Loss: 0.5413 Acc: 0.7833 Current Loss 0.852
    15/30 number of examples 600 Average Acc 79.33
    train Loss: 0.5359 Acc: 0.7933 Current Loss 0.507
    16/30 number of examples 600 Average Acc 75.67
    train Loss: 0.5525 Acc: 0.7567 Current Loss 0.555
    17/30 number of examples 600 Average Acc 82.17
    train Loss: 0.4983 Acc: 0.8217 Current Loss 0.328
    18/30 number of examples 600 Average Acc 82.83
    train Loss: 0.4734 Acc: 0.8283 Current Loss 0.693
    19/30 number of examples 600 Average Acc 80.17
    train Loss: 0.4838 Acc: 0.8017 Current Loss 0.451
    20/30 number of examples 600 Average Acc 81.17
    train Loss: 0.4760 Acc: 0.8117 Current Loss 0.242
    21/30 number of examples 600 Average Acc 81.50
    train Loss: 0.4289 Acc: 0.8150 Current Loss 0.219
    22/30 number of examples 600 Average Acc 85.17
    train Loss: 0.3932 Acc: 0.8517 Current Loss 0.584
    23/30 number of examples 600 Average Acc 83.50
    train Loss: 0.4081 Acc: 0.8350 Current Loss 0.393
    24/30 number of examples 600 Average Acc 80.83
    train Loss: 0.4236 Acc: 0.8083 Current Loss 1.115
    25/30 number of examples 600 Average Acc 83.00
    train Loss: 0.4142 Acc: 0.8300 Current Loss 0.195
    26/30 number of examples 600 Average Acc 82.33
    train Loss: 0.3958 Acc: 0.8233 Current Loss 0.470
    27/30 number of examples 600 Average Acc 81.67
    train Loss: 0.4247 Acc: 0.8167 Current Loss 0.166
    28/30 number of examples 600 Average Acc 83.17
    train Loss: 0.3892 Acc: 0.8317 Current Loss 0.089
    29/30 number of examples 600 Average Acc 84.67
    train Loss: 0.3830 Acc: 0.8467 Current Loss 0.249
    30/30 number of examples 600 Average Acc 81.50
    train Loss: 0.4121 Acc: 0.8150 Current Loss 0.726


Plotting our loss


```python
#loss_list = [ll<0.8]
plt.scatter(range(0,len(ll)),ll)
```




    <matplotlib.collections.PathCollection at 0x7f81f05e1c18>




![png](output_24_1.png)


Here we check our testing accuracy


```python
resnet.eval()
imgl=[] #collecting wrong images
ll=[]
aa=[]  # eval mode 
with torch.no_grad():
    c=0
    count = 0
    running_corrects=0
    for images, labels in test_data_loader:
        count+=1
        l =[]
        a = []
        images = images.cuda()
        labels = labels.cuda()
        l = [i for i in labels.squeeze().data.cpu()]
        ll= ll+l
        outputs = resnet(images)
        loss = criterion(outputs,labels)
        _, preds = torch.max(outputs, 1)
        a = [i for i in preds.data.cpu()]
        aa = aa+a
        for lll in range(0,len(l)):
          if(l[lll].item()!=a[lll].item()):
            imgl.append(images[lll])
        running_corrects += torch.sum(preds == labels.squeeze().data).item()
        c+=len(labels)
print("Overall Accuracy of model is {:.3f}% loss {:.3f} total {}".format((running_corrects/c)*100,loss.item(),count))
```

    Overall Accuracy of model is 85.000% loss 0.621 total 35


Our accuracy for testing is good, we only trained the last layer.
ResNet pre-trained model did a very good job after fine tuning

Lets check our confusion matrix


```python
from sklearn.metrics import confusion_matrix
import seaborn as sns
```


```python
cf = confusion_matrix(ll,aa)
```


```python
sns.heatmap(cf, annot=True)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f4901c8eba8>




![png](output_31_1.png)


#### Lets check on which images our model did wrong


```python
w=10
h=10
fig=plt.figure(figsize=(8, 8))
columns = 4
rows = 5
count=0
for i in imgl:
  if count>15:
    break
  count+=1
  img = np.transpose(i.cpu().numpy(), (1, 2, 0))
  fig.add_subplot(rows, columns,count)
  plt.imshow(img)
plt.show(block=True)
```


![png](output_33_1.png)


### We can see that our model did wrong on some very difficult images.
### Not bad for a finetuned model with single layer
